﻿namespace BoletinCalificaciones
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpEstudiante = new System.Windows.Forms.GroupBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtEstudiante = new System.Windows.Forms.TextBox();
            this.lblTanda = new System.Windows.Forms.Label();
            this.rdbMatutina = new System.Windows.Forms.RadioButton();
            this.rdbVespertina = new System.Windows.Forms.RadioButton();
            this.grpRegistro = new System.Windows.Forms.GroupBox();
            this.lblAsignatura = new System.Windows.Forms.Label();
            this.cmbAsignatura = new System.Windows.Forms.ComboBox();
            this.lblNotas = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP3 = new System.Windows.Forms.Label();
            this.lblP4 = new System.Windows.Forms.Label();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.txtP3 = new System.Windows.Forms.TextBox();
            this.txtP4 = new System.Windows.Forms.TextBox();
            this.chkAsistencia = new System.Windows.Forms.CheckBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.grpBoletin = new System.Windows.Forms.GroupBox();
            this.lstBoletin = new System.Windows.Forms.ListBox();
            this.grpResumen = new System.Windows.Forms.GroupBox();
            this.lblTxtPromedio = new System.Windows.Forms.Label();
            this.lblTxtAprobadas = new System.Windows.Forms.Label();
            this.lblTxtRecuperacion = new System.Windows.Forms.Label();
            this.lblTxtReprobadas = new System.Windows.Forms.Label();
            this.lblPromedioGeneral = new System.Windows.Forms.Label();
            this.lblAprobadas = new System.Windows.Forms.Label();
            this.lblRecuperacion = new System.Windows.Forms.Label();
            this.lblReprobadas = new System.Windows.Forms.Label();
            this.lblSituacion = new System.Windows.Forms.Label();
            this.btnResumen = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.grpEstudiante.SuspendLayout();
            this.grpRegistro.SuspendLayout();
            this.grpBoletin.SuspendLayout();
            this.grpResumen.SuspendLayout();
            this.SuspendLayout();

            // grpEstudiante
            this.grpEstudiante.Controls.Add(this.lblNombre);
            this.grpEstudiante.Controls.Add(this.txtEstudiante);
            this.grpEstudiante.Controls.Add(this.lblTanda);
            this.grpEstudiante.Controls.Add(this.rdbMatutina);
            this.grpEstudiante.Controls.Add(this.rdbVespertina);
            this.grpEstudiante.Location = new System.Drawing.Point(15, 15);
            this.grpEstudiante.Name = "grpEstudiante";
            this.grpEstudiante.Size = new System.Drawing.Size(360, 110);
            this.grpEstudiante.Text = "Datos del estudiante";
            // lblNombre
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(15, 32);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Text = "Nombre:";
            // txtEstudiante
            this.txtEstudiante.Location = new System.Drawing.Point(80, 29);
            this.txtEstudiante.Name = "txtEstudiante";
            this.txtEstudiante.Size = new System.Drawing.Size(265, 23);
            // lblTanda
            this.lblTanda.AutoSize = true;
            this.lblTanda.Location = new System.Drawing.Point(15, 72);
            this.lblTanda.Name = "lblTanda";
            this.lblTanda.Text = "Tanda:";
            // rdbMatutina
            this.rdbMatutina.AutoSize = true;
            this.rdbMatutina.Location = new System.Drawing.Point(80, 70);
            this.rdbMatutina.Name = "rdbMatutina";
            this.rdbMatutina.Text = "Matutina";
            // rdbVespertina
            this.rdbVespertina.AutoSize = true;
            this.rdbVespertina.Location = new System.Drawing.Point(190, 70);
            this.rdbVespertina.Name = "rdbVespertina";
            this.rdbVespertina.Text = "Vespertina";

            // grpRegistro
            this.grpRegistro.Controls.Add(this.lblAsignatura);
            this.grpRegistro.Controls.Add(this.cmbAsignatura);
            this.grpRegistro.Controls.Add(this.lblNotas);
            this.grpRegistro.Controls.Add(this.lblP1);
            this.grpRegistro.Controls.Add(this.lblP2);
            this.grpRegistro.Controls.Add(this.lblP3);
            this.grpRegistro.Controls.Add(this.lblP4);
            this.grpRegistro.Controls.Add(this.txtP1);
            this.grpRegistro.Controls.Add(this.txtP2);
            this.grpRegistro.Controls.Add(this.txtP3);
            this.grpRegistro.Controls.Add(this.txtP4);
            this.grpRegistro.Controls.Add(this.chkAsistencia);
            this.grpRegistro.Controls.Add(this.btnRegistrar);
            this.grpRegistro.Location = new System.Drawing.Point(15, 135);
            this.grpRegistro.Name = "grpRegistro";
            this.grpRegistro.Size = new System.Drawing.Size(360, 230);
            this.grpRegistro.Text = "Registro de asignatura";
            // lblAsignatura
            this.lblAsignatura.AutoSize = true;
            this.lblAsignatura.Location = new System.Drawing.Point(15, 32);
            this.lblAsignatura.Name = "lblAsignatura";
            this.lblAsignatura.Text = "Asignatura:";
            // cmbAsignatura
            this.cmbAsignatura.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAsignatura.Location = new System.Drawing.Point(95, 29);
            this.cmbAsignatura.Name = "cmbAsignatura";
            this.cmbAsignatura.Size = new System.Drawing.Size(250, 23);
            // lblNotas
            this.lblNotas.AutoSize = true;
            this.lblNotas.Location = new System.Drawing.Point(15, 70);
            this.lblNotas.Name = "lblNotas";
            // lblP1..lblP4
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(30, 98);
            this.lblP1.Name = "lblP1";
            this.lblP1.Text = "P1";
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(120, 98);
            this.lblP2.Name = "lblP2";
            this.lblP2.Text = "P2";
            this.lblP3.AutoSize = true;
            this.lblP3.Location = new System.Drawing.Point(210, 98);
            this.lblP3.Name = "lblP3";
            this.lblP3.Text = "P3";
            this.lblP4.AutoSize = true;
            this.lblP4.Location = new System.Drawing.Point(300, 98);
            this.lblP4.Name = "lblP4";
            this.lblP4.Text = "P4";
            // txtP1..txtP4
            this.txtP1.Location = new System.Drawing.Point(15, 120);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(70, 23);
            this.txtP2.Location = new System.Drawing.Point(105, 120);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(70, 23);
            this.txtP3.Location = new System.Drawing.Point(195, 120);
            this.txtP3.Name = "txtP3";
            this.txtP3.Size = new System.Drawing.Size(70, 23);
            this.txtP4.Location = new System.Drawing.Point(285, 120);
            this.txtP4.Name = "txtP4";
            this.txtP4.Size = new System.Drawing.Size(60, 23);
            // chkAsistencia
            this.chkAsistencia.AutoSize = true;
            this.chkAsistencia.Checked = true;
            this.chkAsistencia.Location = new System.Drawing.Point(15, 158);
            this.chkAsistencia.Name = "chkAsistencia";
            // btnRegistrar
            this.btnRegistrar.Location = new System.Drawing.Point(15, 188);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(330, 30);
            this.btnRegistrar.Text = "Registrar asignatura";
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);

            // grpBoletin
            this.grpBoletin.Controls.Add(this.lstBoletin);
            this.grpBoletin.Location = new System.Drawing.Point(390, 15);
            this.grpBoletin.Name = "grpBoletin";
            this.grpBoletin.Size = new System.Drawing.Size(360, 150);
            this.grpBoletin.Text = "Boletín del estudiante";
            // lstBoletin
            this.lstBoletin.FormattingEnabled = true;
            this.lstBoletin.Location = new System.Drawing.Point(12, 25);
            this.lstBoletin.Name = "lstBoletin";
            this.lstBoletin.Size = new System.Drawing.Size(336, 112);

            // grpResumen
            this.grpResumen.Controls.Add(this.lblTxtPromedio);
            this.grpResumen.Controls.Add(this.lblTxtAprobadas);
            this.grpResumen.Controls.Add(this.lblTxtRecuperacion);
            this.grpResumen.Controls.Add(this.lblTxtReprobadas);
            this.grpResumen.Controls.Add(this.lblPromedioGeneral);
            this.grpResumen.Controls.Add(this.lblAprobadas);
            this.grpResumen.Controls.Add(this.lblRecuperacion);
            this.grpResumen.Controls.Add(this.lblReprobadas);
            this.grpResumen.Controls.Add(this.lblSituacion);
            this.grpResumen.Location = new System.Drawing.Point(390, 175);
            this.grpResumen.Name = "grpResumen";
            this.grpResumen.Size = new System.Drawing.Size(360, 190);
            this.grpResumen.Text = "Resumen";
            // Etiquetas de texto
            this.lblTxtPromedio.AutoSize = true;
            this.lblTxtPromedio.Location = new System.Drawing.Point(15, 30);
            this.lblTxtPromedio.Name = "lblTxtPromedio";
            this.lblTxtPromedio.Text = "Promedio general:";
            this.lblTxtAprobadas.AutoSize = true;
            this.lblTxtAprobadas.Location = new System.Drawing.Point(15, 58);
            this.lblTxtAprobadas.Name = "lblTxtAprobadas";
            this.lblTxtAprobadas.Text = "Aprobadas:";
            this.lblTxtRecuperacion.AutoSize = true;
            this.lblTxtRecuperacion.Location = new System.Drawing.Point(15, 86);
            this.lblTxtRecuperacion.Name = "lblTxtRecuperacion";
            this.lblTxtRecuperacion.Text = "En recuperación:";
            this.lblTxtReprobadas.AutoSize = true;
            this.lblTxtReprobadas.Location = new System.Drawing.Point(15, 114);
            this.lblTxtReprobadas.Name = "lblTxtReprobadas";
            this.lblTxtReprobadas.Text = "Reprobadas:";
            // Etiquetas de resultado
            this.lblPromedioGeneral.AutoSize = true;
            this.lblPromedioGeneral.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPromedioGeneral.Location = new System.Drawing.Point(300, 30);
            this.lblPromedioGeneral.Name = "lblPromedioGeneral";
            this.lblAprobadas.AutoSize = true;
            this.lblAprobadas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAprobadas.Location = new System.Drawing.Point(300, 58);
            this.lblAprobadas.Name = "lblAprobadas";
            this.lblRecuperacion.AutoSize = true;
            this.lblRecuperacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblRecuperacion.Location = new System.Drawing.Point(300, 86);
            this.lblRecuperacion.Name = "lblRecuperacion";
            this.lblReprobadas.AutoSize = true;
            this.lblReprobadas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblReprobadas.Location = new System.Drawing.Point(300, 114);
            this.lblReprobadas.Name = "lblReprobadas";
            this.lblSituacion.AutoSize = true;
            this.lblSituacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblSituacion.Location = new System.Drawing.Point(15, 150);
            this.lblSituacion.Name = "lblSituacion";

            // Botones inferiores
            this.btnResumen.Location = new System.Drawing.Point(15, 380);
            this.btnResumen.Name = "btnResumen";
            this.btnResumen.Size = new System.Drawing.Size(230, 32);
            this.btnResumen.Text = "Mostrar resumen";
            this.btnResumen.Click += new System.EventHandler(this.btnResumen_Click);
            this.btnLimpiar.Location = new System.Drawing.Point(270, 380);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(230, 32);
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            this.btnSalir.Location = new System.Drawing.Point(520, 380);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(230, 32);
            this.btnSalir.Text = "Salir";
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 430);
            this.Controls.Add(this.grpEstudiante);
            this.Controls.Add(this.grpRegistro);
            this.Controls.Add(this.grpBoletin);
            this.Controls.Add(this.grpResumen);
            this.Controls.Add(this.btnResumen);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnSalir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Boletín de Calificaciones";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpEstudiante.ResumeLayout(false);
            this.grpEstudiante.PerformLayout();
            this.grpRegistro.ResumeLayout(false);
            this.grpRegistro.PerformLayout();
            this.grpBoletin.ResumeLayout(false);
            this.grpResumen.ResumeLayout(false);
            this.grpResumen.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox grpEstudiante;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtEstudiante;
        private System.Windows.Forms.Label lblTanda;
        private System.Windows.Forms.RadioButton rdbMatutina;
        private System.Windows.Forms.RadioButton rdbVespertina;
        private System.Windows.Forms.GroupBox grpRegistro;
        private System.Windows.Forms.Label lblAsignatura;
        private System.Windows.Forms.ComboBox cmbAsignatura;
        private System.Windows.Forms.Label lblNotas;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP3;
        private System.Windows.Forms.Label lblP4;
        private System.Windows.Forms.TextBox txtP1;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.TextBox txtP3;
        private System.Windows.Forms.TextBox txtP4;
        private System.Windows.Forms.CheckBox chkAsistencia;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.GroupBox grpBoletin;
        private System.Windows.Forms.ListBox lstBoletin;
        private System.Windows.Forms.GroupBox grpResumen;
        private System.Windows.Forms.Label lblTxtPromedio;
        private System.Windows.Forms.Label lblTxtAprobadas;
        private System.Windows.Forms.Label lblTxtRecuperacion;
        private System.Windows.Forms.Label lblTxtReprobadas;
        private System.Windows.Forms.Label lblPromedioGeneral;
        private System.Windows.Forms.Label lblAprobadas;
        private System.Windows.Forms.Label lblRecuperacion;
        private System.Windows.Forms.Label lblReprobadas;
        private System.Windows.Forms.Label lblSituacion;
        private System.Windows.Forms.Button btnResumen;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
    }
}