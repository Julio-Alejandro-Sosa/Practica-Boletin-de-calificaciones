using System;
using System.Windows.Forms;
    
namespace BoletinCalificaciones
{
    public partial class Form1 : Form
    {
        // ---------- CONSTANTES (ningún valor fijo en la lógica) ----------
        private const int PERIODOS = 4;                 // cantidad de calificaciones por asignatura
        private const double NOTA_APROBADO = 70;        // desde aquí: Aprobada
        private const double NOTA_RECUPERACION = 60;    // desde aquí: En recuperación
        private const double NOTA_MINIMA = 0;           // calificación mínima válida
        private const double NOTA_MAXIMA = 100;         // calificación máxima válida
        private const int ASISTENCIA_MINIMA = 80;       // % de asistencia requerido
        private const string FORMATO = "F2";            // 2 decimales
        private const string SEPARADOR = " · ";

        // Textos de situación por asignatura
        private const string SIT_APROBADA = "Aprobada";
        private const string SIT_RECUPERACION = "En recuperación";
        private const string SIT_REPROBADA = "Reprobada";
        private const string SIT_REPROBADA_ASISTENCIA = "Reprobada por asistencia";

        // Textos de situación general
        private const string GEN_APROBO = "Aprobó todas las asignaturas";
        private const string GEN_RECUPERACION = "Tiene asignaturas en recuperación";
        private const string GEN_REPROBADAS = "Tiene asignaturas reprobadas";

        // Textos de validación
        private const string TITULO_ERROR = "Dato inválido";
        private const string MSG_NOMBRE = "Escriba el nombre del estudiante.";
        private const string MSG_TANDA = "Seleccione la tanda.";
        private const string MSG_ASIGNATURA = "Seleccione una asignatura.";
        private const string MSG_NOTA = "Cada calificación debe ser un número entre {0} y {1}.";
        private const string MSG_SIN_REGISTROS = "Registre al menos una asignatura antes de mostrar el resumen.";

        // ---------- VARIABLES A NIVEL DE FORMULARIO (acumuladores) ----------
        private double sumaPromedios;
        private int cantAprobadas;
        private int cantRecuperacion;
        private int cantReprobadas;

        // Arreglo con las cajas de calificaciones para recorrerlas con un ciclo
        private TextBox[] cajasNotas;

        public Form1()
        {
            InitializeComponent();
        }

        // Evento Load: carga el ComboBox y deja el formulario en estado inicial
        private void Form1_Load(object sender, EventArgs e)
        {
            cajasNotas = new TextBox[] { txtP1, txtP2, txtP3, txtP4 };
            cmbAsignatura.Items.AddRange(new object[]
            {
                "Matemática", "Lengua Española", "Ciencias Naturales", "Inglés", "Informática"
            });
            chkAsistencia.Text = "Cumple la asistencia mínima (" + ASISTENCIA_MINIMA + " %)";
            lblNotas.Text = "Calificaciones por período (" + NOTA_MINIMA + " a " + NOTA_MAXIMA + "):";
            LimpiarFormulario();
        }

        // Evento Click de btnRegistrar: valida, calcula y agrega la asignatura a la lista
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // --- Validaciones ---
            if (txtEstudiante.Text.Trim() == "")
            {
                MessageBox.Show(MSG_NOMBRE, TITULO_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEstudiante.Focus();
                return;
            }
            if (!rdbMatutina.Checked && !rdbVespertina.Checked)
            {
                MessageBox.Show(MSG_TANDA, TITULO_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbAsignatura.SelectedIndex < 0)
            {
                MessageBox.Show(MSG_ASIGNATURA, TITULO_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbAsignatura.Focus();
                return;
            }

            // Lee y valida cada calificación con double.TryParse
            double suma = 0;
            foreach (TextBox caja in cajasNotas)
            {
                double nota;
                if (!double.TryParse(caja.Text.Trim(), out nota) || nota < NOTA_MINIMA || nota > NOTA_MAXIMA)
                {
                    MessageBox.Show(string.Format(MSG_NOTA, NOTA_MINIMA, NOTA_MAXIMA),
                                    TITULO_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    caja.Focus();
                    caja.SelectAll();
                    return;
                }
                suma += nota;
            }

            // --- Cálculos ---
            double promedio = suma / PERIODOS;
            string situacion;

            if (!chkAsistencia.Checked)
            {
                // Sin asistencia mínima: reprobada sin importar el promedio
                situacion = SIT_REPROBADA_ASISTENCIA;
                cantReprobadas++;
            }
            else if (promedio >= NOTA_APROBADO)
            {
                situacion = SIT_APROBADA;
                cantAprobadas++;
            }
            else if (promedio >= NOTA_RECUPERACION)
            {
                situacion = SIT_RECUPERACION;
                cantRecuperacion++;
            }
            else
            {
                situacion = SIT_REPROBADA;
                cantReprobadas++;
            }

            sumaPromedios += promedio;

            // Agrega la línea al ListBox
            lstBoletin.Items.Add(cmbAsignatura.Text + SEPARADOR + promedio.ToString(FORMATO) + SEPARADOR + situacion);

            // Prepara el formulario para la siguiente asignatura
            cmbAsignatura.SelectedIndex = -1;
            foreach (TextBox caja in cajasNotas)
            {
                caja.Clear();
            }
            chkAsistencia.Checked = true;
            cmbAsignatura.Focus();
        }

        // Evento Click de btnResumen: muestra promedio general, conteos y situación general
        private void btnResumen_Click(object sender, EventArgs e)
        {
            int total = cantAprobadas + cantRecuperacion + cantReprobadas;

            if (total == 0)
            {
                MessageBox.Show(MSG_SIN_REGISTROS, TITULO_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            double promedioGeneral = sumaPromedios / total;

            lblPromedioGeneral.Text = promedioGeneral.ToString(FORMATO);
            lblAprobadas.Text = cantAprobadas.ToString();
            lblRecuperacion.Text = cantRecuperacion.ToString();
            lblReprobadas.Text = cantReprobadas.ToString();

            if (cantReprobadas > 0)
            {
                lblSituacion.Text = "Situación: " + GEN_REPROBADAS;
            }
            else if (cantRecuperacion > 0)
            {
                lblSituacion.Text = "Situación: " + GEN_RECUPERACION;
            }
            else
            {
                lblSituacion.Text = "Situación: " + GEN_APROBO;
            }
        }

        // Evento Click de btnLimpiar: deja el formulario como al iniciar
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }

        // Evento Click de btnSalir: cierra la aplicación
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Método auxiliar: reinicia controles, contadores y acumuladores
        private void LimpiarFormulario()
        {
            txtEstudiante.Clear();
            rdbMatutina.Checked = false;
            rdbVespertina.Checked = false;
            cmbAsignatura.SelectedIndex = -1;
            foreach (TextBox caja in cajasNotas)
            {
                caja.Clear();
            }
            chkAsistencia.Checked = true;
            lstBoletin.Items.Clear();

            sumaPromedios = 0;
            cantAprobadas = 0;
            cantRecuperacion = 0;
            cantReprobadas = 0;

            lblPromedioGeneral.Text = 0.ToString(FORMATO);
            lblAprobadas.Text = cantAprobadas.ToString();
            lblRecuperacion.Text = cantRecuperacion.ToString();
            lblReprobadas.Text = cantReprobadas.ToString();
            lblSituacion.Text = "Situación:";
            txtEstudiante.Focus();
        }
    }
}